import flet as ft
import time
import cv2
import os
from datetime import date, datetime
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd
import joblib
import pygetwindow as gw
import warnings

def bring_window_to_front(window_name):
    open_windows = gw.getAllTitles()
        
    if window_name in open_windows:
        window = gw.getWindowsWithTitle(window_name)[0]
        
        if window.isActive:
            return
        # Try minimizing and then restoring the window
        window.minimize()
        time.sleep(0.1) 
        window.restore() 
            
        # Activate the window to bring it to the front
        window.activate()
        window.alwaysOnTop = True 

class AttendanceApp:
    def __init__(self):
        # Initialize constants and paths
        self.datetoday = date.today().strftime("%m_%d_%y")
        self.datetoday2 = date.today().strftime("%d-%B-%Y")
        self.haarcascade_path = "haarcascade_frontalface_default.xml"
        self.face_cascade = cv2.CascadeClassifier(self.haarcascade_path)
        self.global_model = None
        
        # Define paths
        self.attendance_dir = 'Attendance'
        self.static_dir = 'static'
        self.faces_dir = os.path.join(self.static_dir, 'faces')
        
        # Create necessary directories
        for directory in [self.attendance_dir, self.static_dir, self.faces_dir]:
            if not os.path.isdir(directory):
                os.makedirs(directory)
                
        # Initialize attendance file
        self.attendance_csv = os.path.join(self.attendance_dir, f'Attendance-{self.datetoday}.csv')
        if not os.path.exists(self.attendance_csv):
            with open(self.attendance_csv, 'w') as f:
                f.write('Name,Roll,Time')

    def totalreg(self):
        try:
            return len([f for f in os.listdir(self.faces_dir) if os.path.isdir(os.path.join(self.faces_dir, f))])
        except:
            return 0

    def extract_faces(self, img):
        if img != []:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            face_points = self.face_cascade.detectMultiScale(gray, 1.3, 5)
            return face_points
        return []

    def identify_face(self, facearray):
        model_path = os.path.join(self.static_dir, 'face_recognition_model.pkl')
        model = joblib.load(model_path)
        return model.predict(facearray)

    def calculate_confidence(self, face_array, model):
        distances, indices = model.kneighbors(face_array)
        closest_distance = distances[0][0]
        confidence = 1 - (closest_distance / 25.0)
        return confidence, indices[0][0]

    def add_attendance(self, name):
        username = name.split('_')[0]
        userid = name.split('_')[1]
        current_time = datetime.now().strftime("%H:%M:%S")
        
        df = pd.read_csv(self.attendance_csv)
        if str(userid) not in list(df['Roll']):
            with open(self.attendance_csv, 'a') as f:
                f.write(f'\n{username},{userid},{current_time}')

    def extract_attendance(self):
        df = pd.read_csv(self.attendance_csv)
        names = df['Name']
        rolls = df['Roll']
        times = df['Time']
        l = len(df)
        return names, rolls, times, l

    def train_model(self):
        faces = []
        labels = []
        userlist = os.listdir(self.faces_dir)
        print("Starting model training...")
        
        for user in userlist:
            user_path = os.path.join(self.faces_dir, user)
            if not os.path.isdir(user_path):
                continue
                
            user_images = os.listdir(user_path)
            print(f"Processing user {user} with {len(user_images)} images")
            
            for imgname in user_images:
                img_path = os.path.join(user_path, imgname)
                img = cv2.imread(img_path)
                if img is None:
                    print(f"Failed to load image: {img_path}")
                    continue
                    
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                resized_face = cv2.resize(gray, (50, 50))
                face_array = resized_face.flatten().astype(np.float32) / 255.0
                
                current_user = str(os.path.basename(user_path))
                faces.append(face_array)
                labels.append(current_user)
                
        if not faces:
            print("No faces were processed!")
            return
            
        faces = np.array(faces)
        labels = np.array(labels)
        
        unique_labels = set(labels)
        print(f"Training with {len(faces)} faces")
        print(f"Number of unique users: {len(unique_labels)}")
        print(f"Unique users: {unique_labels}")
        
        knn = KNeighborsClassifier(n_neighbors=5, weights='distance')
        knn.fit(faces, labels)
        
        model_path = os.path.join(self.static_dir, 'face_recognition_model.pkl')
        joblib.dump(knn, model_path)
        print("Model training completed and saved")

    def take_attendance(self, e, page: ft.Page, attendance_table):
        try:
            if self.totalreg() == 0:
                snack = ft.SnackBar(content=ft.Text("Please add at least one student before taking attendance!"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return

            model_path = os.path.join(self.static_dir, 'face_recognition_model.pkl')
            if not os.path.exists(model_path):
                snack = ft.SnackBar(content=ft.Text("No trained model found. Please add a student first."))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return

            if self.global_model is None:
                self.global_model = joblib.load(model_path)

            cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            cap.set(cv2.CAP_PROP_FPS, 60)

            # Stability buffer
            last_predictions = []
            BUFFER_SIZE = 5
            
            # Recognition thresholds
            MAX_DISTANCE = 25.0
            CONFIDENCE_THRESHOLD = 0.45
            MIN_CONFIDENCE_COUNT = 3

            # Counter for consecutive successful recognitions
            successful_frames = 0
            REQUIRED_SUCCESSFUL_FRAMES = 10

            # No face detection timer
            no_face_start_time = None
            NO_FACE_DELAY = 2

            while True:
                ret, frame = cap.read()
                if not ret:
                    continue

                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = self.face_cascade.detectMultiScale(
                    gray,
                    scaleFactor=1.1,
                    minNeighbors=4,
                    minSize=(30, 30),
                    maxSize=(300, 300)
                )

                if len(faces) == 1:
                    no_face_start_time = None
                    x, y, w, h = faces[0]
                    try:
                        face = frame[y:y+h, x:x+w]
                        face_gray = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
                        face_resized = cv2.resize(face_gray, (50, 50))
                        face_array = face_resized.flatten().astype(np.float32) / 255.0
                        face_array = face_array.reshape(1, -1)
                        
                        identified_person = str(self.global_model.predict(face_array)[0])
                        
                        distances, indices = self.global_model.kneighbors(face_array)
                        closest_distance = distances[0][0]
                        confidence = 1 - (closest_distance / MAX_DISTANCE)
                        
                        last_predictions.append((identified_person, confidence))
                        if len(last_predictions) > BUFFER_SIZE:
                            last_predictions.pop(0)
                        
                        stable_recognition = False
                        if len(last_predictions) == BUFFER_SIZE:
                            confident_predictions = sum(1 for p, c in last_predictions 
                                                     if p == identified_person and c > CONFIDENCE_THRESHOLD)
                            stable_recognition = confident_predictions >= MIN_CONFIDENCE_COUNT
                        
                        if confidence > CONFIDENCE_THRESHOLD and stable_recognition:
                            successful_frames += 1
                            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                            display_name = identified_person.split('_')[0]
                            cv2.putText(frame, display_name, 
                                      (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                            
                            if successful_frames >= REQUIRED_SUCCESSFUL_FRAMES:
                                self.add_attendance(identified_person)
                                cv2.putText(frame, 'Attendance Marked!', (30, 30), 
                                          cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                                cv2.imshow('Attendance Check', frame)
                                cv2.waitKey(1000)
                                
                                # Update attendance table
                                names, rolls, times, l = self.extract_attendance()
                                attendance_table.rows.clear()
                                for i in range(l):
                                    attendance_table.rows.append(
                                        ft.DataRow(
                                            cells=[
                                                ft.DataCell(ft.Text(str(i+1))),
                                                ft.DataCell(ft.Text(names[i])),
                                                ft.DataCell(ft.Text(rolls[i])),
                                                ft.DataCell(ft.Text(times[i]))
                                            ]
                                        )
                                    )
                                try:
                                    page.update()
                                except Exception:
                                    pass
                                break
                        
                    except Exception as e:
                        print(f"Error processing face: {str(e)}")
                        continue
                else:
                    successful_frames = 0
                    current_time = time.time()
                    
                    if len(faces) > 1:
                        no_face_start_time = None
                        cv2.putText(frame, 'Please show only one face', (30, 30), 
                                  cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
                    else:
                        if no_face_start_time is None:
                            no_face_start_time = current_time
                        elif current_time - no_face_start_time >= NO_FACE_DELAY:
                            cv2.putText(frame, 'No face detected', (30, 30), 
                                      cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

                cv2.imshow('Attendance Check', frame)
                bring_window_to_front('Attendance Check')

                if cv2.waitKey(1) == 27:
                    break

            cap.release()
            cv2.destroyAllWindows()

            # Update attendance table
            names, rolls, times, l = self.extract_attendance()
            attendance_table.rows.clear()
            for i in range(l):
                attendance_table.rows.append(
                    ft.DataRow(
                        cells=[
                            ft.DataCell(ft.Text(str(i+1))),
                            ft.DataCell(ft.Text(names[i])),
                            ft.DataCell(ft.Text(rolls[i])),
                            ft.DataCell(ft.Text(times[i]))
                        ],
                        # Remove height and color as they're not supported
                    )
                )
            page.update()

        except Exception as e:
            try:
                snack = ft.SnackBar(content=ft.Text(f"Error: {str(e)}"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
            except Exception:
                pass  # Ignore errors when page is closed

    def add_student(self, e, page: ft.Page, student_name, roll_number, total_students_text):
        try:
            name = student_name.value
            roll = roll_number.value

            if not name or not roll:
                snack = ft.SnackBar(content=ft.Text("Please enter both name and roll number"))
                page.overlay.append(snack)
                snack.open = True
                page.update()
                return

            student_dir = os.path.join(self.faces_dir, f"{name}_{roll}")
            if not os.path.exists(student_dir):
                os.makedirs(student_dir)

            cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            cap.set(cv2.CAP_PROP_FPS, 60)
            
            i, j = 0, 0
            no_face_start_time = None
            NO_FACE_DELAY = 5

            while i < 100:
                ret, frame = cap.read()
                if ret:
                    faces = self.extract_faces(frame)
                    current_time = time.time()
                    
                    if len(faces) > 0:
                        no_face_start_time = None
                        for (x, y, w, h) in faces:
                            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 20), 2)
                            cv2.putText(frame, f'Scanning: {i}/100', (30, 30),
                                      cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 20), 2)
                            
                            if j % 2 == 0:
                                face = frame[y:y + h, x:x + w]
                                face_gray = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
                                face_gray = cv2.normalize(face_gray, None, 0, 255, cv2.NORM_MINMAX)
                                padding = 10
                                face_gray = cv2.copyMakeBorder(
                                    face_gray, padding, padding, padding, padding,
                                    cv2.BORDER_CONSTANT, value=[0]
                                )
                                
                                cv2.imwrite(os.path.join(student_dir, f'{i}.jpg'), face)
                                i += 1
                                if i >= 100:
                                    break
                            j += 1
                    else:
                        if no_face_start_time is None:
                            no_face_start_time = current_time
                        elif current_time - no_face_start_time >= NO_FACE_DELAY:
                            cv2.putText(frame, 'No face detected!', (30, 30),
                                      cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

                    cv2.imshow('Adding new Student', frame)
                    bring_window_to_front('Adding new Student')

                    if cv2.waitKey(1) & 0xFF == ord('q'):
                        break

            cap.release()
            cv2.destroyAllWindows()

            self.train_model()

            student_name.value = ""
            roll_number.value = ""
            total_students_text.value = f"Total Students in Database: {self.totalreg()}"
            
            page.update()
            page.show_snack_bar(
                ft.SnackBar(content=ft.Text("Student added successfully!"))
            )

        except Exception as e:
            snack = ft.SnackBar(content=ft.Text(f"Error: {str(e)}"))
            page.overlay.append(snack)
            snack.open = True
            page.update()

    def clear_attendance(self, e, page: ft.Page, attendance_table):
        try:
            # Clear the CSV file by rewriting the header
            with open(self.attendance_csv, 'w') as f:
                f.write('Name,Roll,Time')
            
            # Clear the table rows
            attendance_table.rows.clear()
            page.update()
            
            # Show success message
            page.show_snack_bar(
                ft.SnackBar(content=ft.Text("Attendance cleared successfully!"))
            )
        except Exception as e:
            snack = ft.SnackBar(content=ft.Text(f"Error clearing attendance: {str(e)}"))
            page.overlay.append(snack)
            snack.open = True
            page.update()

    def main_page(self, page: ft.Page):
        page.title = "Face Recognition Based Attendance System"
        page.theme_mode = ft.ThemeMode.DARK
        page.padding = 20
        page.window_bgcolor = "#2C2C2E"
        page.bgcolor = "#2C2C2E"
        page.window_width = 1200
        page.window_height = 800

        # Update color scheme back to yellow
        primary_color = "#FFD700"  # Yellow
        secondary_color = "#4A4A4C"  # Dark gray
        text_color = "white"

        # Create references for text fields
        student_name = ft.Ref[ft.TextField]()
        roll_number = ft.Ref[ft.TextField]()
        total_students_text = ft.Ref[ft.Text]()

        # Sidebar style
        sidebar_style = {
            "bgcolor": "#1C1C1E",
            "padding": 20,
            "border_radius": 15,
            "width": 280,
        }

        # Main content style
        content_style = {
            "bgcolor": "#1C1C1E",
            "padding": 20,
            "border_radius": 15,
            "expand": True,
        }

        # Stats card style
        stats_card_style = {
            "bgcolor": secondary_color,
            "padding": 15,
            "border_radius": 10,
            "width": 200,
            "height": 120,
        }

        # Create sidebar content
        sidebar = ft.Container(
            content=ft.Column([
                ft.Text("Face Recognition", size=24, weight=ft.FontWeight.BOLD, color=primary_color),
                ft.Text("Attendance System", size=16, color=text_color),
                ft.Divider(color=secondary_color),
                
                # Center aligned container for student inputs
                ft.Container(
                    content=ft.Column([
                        ft.TextField(
                            ref=student_name,
                            label="Student Name",
                            border_color=primary_color,
                            color=text_color,
                            bgcolor=ft.colors.with_opacity(0.1, secondary_color),
                            width=250,
                            border_radius=30,  # Make it circular
                            text_align=ft.TextAlign.CENTER,  # Center the text
                            border=ft.InputBorder.UNDERLINE,  # Use underline border for cleaner look
                        ),
                        ft.TextField(
                            ref=roll_number,
                            label="Roll Number",
                            border_color=primary_color,
                            color=text_color,
                            bgcolor=ft.colors.with_opacity(0.1, secondary_color),
                            width=250,
                            border_radius=30,  # Make it circular
                            text_align=ft.TextAlign.CENTER,  # Center the text
                            border=ft.InputBorder.UNDERLINE,  # Use underline border for cleaner look
                        ),
                        ft.Container(  # Container for centered button
                            content=ft.ElevatedButton(
                                "Add New Student",
                                style=ft.ButtonStyle(
                                    bgcolor=primary_color,
                                    color="black",
                                    shape=ft.RoundedRectangleBorder(radius=20),  # More rounded corners
                                ),
                                on_click=lambda e: self.add_student(e, page, student_name.current, roll_number.current, total_students_text.current),
                            ),
                            alignment=ft.alignment.center,
                        ),
                        ft.Container(  # Container for centered text
                            content=ft.Text(
                                ref=total_students_text,
                                value=f"Total Students: {self.totalreg()}",
                                color=text_color,
                                size=14,
                            ),
                            alignment=ft.alignment.center,
                        ),
                    ]),
                    alignment=ft.alignment.center,
                ),
            ]),
            **{
                **sidebar_style,
                "bgcolor": ft.colors.with_opacity(0.85, "#1C1C1E"),  # Add transparency to sidebar
            }
        )

        # Create attendance table with transparency
        attendance_table = ft.DataTable(
            border_radius=10,
            heading_row_color=ft.colors.with_opacity(0.7, secondary_color),  # Add transparency to header
            heading_row_height=70,
            data_row_color={
                "hovered": ft.colors.with_opacity(0.2, "#87CEEB"),  # Sky blue hover effect
            },
            columns=[
                ft.DataColumn(ft.Text("S No", color=text_color, text_align=ft.TextAlign.CENTER)),
                ft.DataColumn(ft.Text("Name", color=text_color, text_align=ft.TextAlign.CENTER)),
                ft.DataColumn(ft.Text("ID", color=text_color, text_align=ft.TextAlign.CENTER)),
                ft.DataColumn(ft.Text("Time", color=text_color, text_align=ft.TextAlign.CENTER)),
            ],
            rows=[],
        )

        # Create stats cards
        stats_section = ft.Row([
            ft.Container(
                content=ft.Column([
                    ft.Icon(ft.icons.PEOPLE_ALT, color=primary_color, size=30),
                    ft.Text("Total Students", color=text_color),
                    ft.Text(str(self.totalreg()), size=24, color=primary_color),
                ], alignment=ft.MainAxisAlignment.CENTER),
                **stats_card_style
            ),
            ft.Container(
                content=ft.Column([
                    ft.Icon(ft.icons.TODAY, color=primary_color, size=30),
                    ft.Text("Today's Date", color=text_color),
                    ft.Text(self.datetoday2, size=20, color=primary_color),
                ], alignment=ft.MainAxisAlignment.CENTER),
                **stats_card_style
            ),
        ], alignment=ft.MainAxisAlignment.CENTER)

        # Action buttons
        action_buttons = ft.Row([
            ft.ElevatedButton(
                "Take Attendance",
                style=ft.ButtonStyle(
                    bgcolor=primary_color,
                    color="black",
                    shape=ft.RoundedRectangleBorder(radius=20),
                ),
                on_click=lambda e: self.take_attendance(e, page, attendance_table),
            ),
            ft.ElevatedButton(
                "Clear Attendance",
                style=ft.ButtonStyle(
                    bgcolor=secondary_color,
                    color=text_color,
                    shape=ft.RoundedRectangleBorder(radius=20),
                ),
                on_click=lambda e: self.clear_attendance(e, page, attendance_table),
            ),
        ], alignment=ft.MainAxisAlignment.CENTER)

        # Main content area with transparency
        main_content = ft.Container(
            content=ft.Column([
                stats_section,
                ft.Divider(color=secondary_color),
                action_buttons,
                ft.Divider(color=secondary_color),
                ft.Container(  # Container for centered table
                    content=attendance_table,
                    alignment=ft.alignment.center,
                    padding=20,
                ),
            ], alignment=ft.MainAxisAlignment.CENTER),  # Center align all content
            **{
                **content_style,
                "bgcolor": ft.colors.with_opacity(0.85, "#1C1C1E"),  # Add transparency to main content
            }
        )

        # Layout everything in a row
        page.add(
            ft.Row([
                sidebar,
                ft.VerticalDivider(width=1, color=secondary_color),
                main_content,
            ], expand=True)
        )

        # Load existing attendance
        names, rolls, times, l = self.extract_attendance()
        for i in range(l):
            attendance_table.rows.append(
                ft.DataRow(
                    cells=[
                        ft.DataCell(ft.Text(str(i+1), color=text_color)),
                        ft.DataCell(ft.Text(names[i], color=text_color)),
                        ft.DataCell(ft.Text(rolls[i], color=text_color)),
                        ft.DataCell(ft.Text(times[i], color=text_color)),
                    ],
                )
            )

    def run(self):
        # Suppress deprecation warnings
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        
        try:
            # Create assets directory if it doesn't exist
            if not os.path.exists("assets"):
                os.makedirs("assets")
            
            # Use desktop app view with minimal configuration
            ft.app(
                target=self.main_page,
                view=ft.AppView.FLET_APP,
                assets_dir="assets",
                name="Face Recognition Attendance"  # Add a name for the window
            )
        except Exception as e:
            print(f"Application error: {str(e)}")
            import traceback
            traceback.print_exc()
        finally:
            cv2.destroyAllWindows()

if __name__ == "__main__":
    try:
        app = AttendanceApp()
        app.run()
    except Exception as e:
        print(f"Initialization error: {str(e)}")
        import traceback
        traceback.print_exc()