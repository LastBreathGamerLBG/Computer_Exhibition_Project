import time
import cv2
import pygetwindow as gw
import os
from flask import Flask, request, render_template, redirect, session, url_for
from datetime import date
from datetime import datetime
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd
import joblib
import shutil

global_model = None

# Defining Flask App
app = Flask(__name__)
app.secret_key = "5ba6ca4a6073e1f5ac4cbcd0c5256f61fc134066d53b7e5fc0a688f6dbbe57b8"

# Load the Haar Cascade directly
haarcascade_path = "haarcascade_frontalface_default.xml"
face_cascade = cv2.CascadeClassifier(haarcascade_path)

def bring_window_to_front(window_name):
    open_windows = gw.getAllTitles()
        
    if window_name in open_windows:
        window = gw.getWindowsWithTitle(window_name)[0]
        
        if window.isActive:
            return
        # Try minimizing and then restoring the window
        window.minimize()
        time.sleep(0.1) 
        window.restore() 
            
        # Activate the window to bring it to the front
        window.activate()
        window.alwaysOnTop = True 

# Saving Date today in 2 different formats
datetoday = date.today().strftime("%m_%d_%y")
datetoday2 = date.today().strftime("%d-%B-%Y")

# Initializing VideoCapture object to access WebCam
face_detector = cv2.CascadeClassifier(haarcascade_path)
try:
    cap = cv2.VideoCapture(1)  # 1 for external webcam
except:
    cap = cv2.VideoCapture(0)  # 0 for internal webcam

# Define paths for directories
attendance_dir = 'Attendance'
static_dir = 'static'
faces_dir = os.path.join(static_dir, 'faces') 

# If these directories don't exist, create them
if not os.path.isdir(attendance_dir):
    os.makedirs(attendance_dir)

if not os.path.isdir(static_dir):
    os.makedirs(static_dir)

if not os.path.isdir(faces_dir):
    os.makedirs(faces_dir)

# Create attendance CSV file if it doesn't exist
attendance_csv = os.path.join(attendance_dir, f'Attendance-{datetoday}.csv')
if not os.path.exists(attendance_csv):
    with open(attendance_csv, 'w') as f:
        f.write('Name,Roll,Time')

# Get a number of total registered users
def totalreg():
    return len(os.listdir(faces_dir))

# Extract the face from an image
def extract_faces(img):
    if img != []:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        face_points = face_detector.detectMultiScale(gray, 1.3, 5)
        return face_points
    else:
        return []

# Identify face using ML model
def identify_face(facearray):
    model_path = os.path.join(static_dir, 'face_recognition_model.pkl')
    model = joblib.load(model_path)
    
    # Get distances and indices of k nearest neighbors
    distances, indices = model.kneighbors(facearray)
    
    # If the closest match is too far away, return None
    if distances[0][0] > 0.5:  # Adjust this threshold if needed
        return None
        
    return model.predict(facearray)

# A function which trains the model on all the faces available in faces folder
def train_model():
    faces = []
    labels = []
    userlist = os.listdir(faces_dir)
    print("Starting model training...")
    
    # Clear any existing model first
    model_path = os.path.join(static_dir, 'face_recognition_model.pkl')
    if os.path.exists(model_path):
        os.remove(model_path)
    
    for user in userlist:
        user_path = os.path.join(faces_dir, user)
        if not os.path.isdir(user_path):
            continue
            
        user_images = os.listdir(user_path)
        print(f"Processing user {user} with {len(user_images)} images")
        
        for imgname in user_images:
            img_path = os.path.join(user_path, imgname)
            img = cv2.imread(img_path)
            if img is None:
                print(f"Failed to load image: {img_path}")
                continue
                
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            resized_face = cv2.resize(gray, (50, 50))  # Keeping same dimensions
            face_array = resized_face.flatten().astype(np.float32) / 255.0
            
            # Make sure each image is labeled with the correct username
            current_user = os.path.basename(user_path)  # This gets the full username_id
            faces.append(face_array)
            labels.append(current_user)
            
    if not faces:
        print("No faces were processed!")
        return
        
    faces = np.array(faces)
    
    # Print debug information
    unique_labels = set(labels)
    print(f"Training with {len(faces)} faces")
    print(f"Number of unique users: {len(unique_labels)}")
    print(f"Unique users: {unique_labels}")
    
    # Train with more neighbors for better accuracy
    knn = KNeighborsClassifier(n_neighbors=5, weights='distance')
    knn.fit(faces, labels)
    
    model_path = os.path.join(static_dir, 'face_recognition_model.pkl')
    joblib.dump(knn, model_path)
    print("Model training completed and saved")

# Extract attendance from attendance CSV file
def extract_attendance():
    df = pd.read_csv(attendance_csv)
    names = df['Name']
    rolls = df['Roll']
    times = df['Time']
    l = len(df)
    return names, rolls, times, l

# Modify the add_attendance function to handle unknown users
def add_attendance(name):
    username = name.split('_')[0]
    userid = name.split('_')[1]
    current_time = datetime.now().strftime("%I:%M %p")
    
    df = pd.read_csv(attendance_csv)
    if str(userid) not in list(df['Roll']):
        with open(attendance_csv, 'a') as f:
            f.write(f'\n{username},{userid},{current_time}')

# Add this function to calculate confidence score
def calculate_confidence(face_array, model):
    distances, indices = model.kneighbors(face_array)
    # Get the mean distance of k nearest neighbors
    avg_distance = np.mean(distances[0])
    # Convert distance to confidence score (closer to 0 means more confident)
    confidence = 1 / (1 + avg_distance)
    return confidence

# Our main page
@app.route('/')
def index():
    names, rolls, times, l = extract_attendance()    
    message = session.pop('message', None)
    total_students = len(os.listdir(faces_dir))  # Direct calculation
    return render_template('index.html', 
                         names=names, 
                         rolls=rolls, 
                         times=times, 
                         l=l, 
                         total_students=total_students,  # Pass the number directly
                         datetoday2=datetoday2,
                         mess=message)

# This function will run when we click on Take Attendance Button
@app.route('/start', methods=['GET'])
def start():
    # First check if any students are registered
    if totalreg() == 0:
        session['message'] = 'Please add at least one student before taking attendance!'
        return redirect(url_for('index'))

    # Check for model file
    model_path = os.path.join(static_dir, 'face_recognition_model.pkl')
    if not os.path.exists(model_path):
        session['message'] = 'There is no trained model in the static folder. Please add a new face to continue.'
        return redirect(url_for('index'))

    # Initialize model
    global global_model
    if global_model is None:
        try:
            global_model = joblib.load(model_path)
        except Exception as e:
            session['message'] = 'Error loading the model. Please add a new face to continue.'
            return redirect(url_for('index'))

    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    cap.set(cv2.CAP_PROP_FPS, 60)
    
    # Stability buffer
    last_predictions = []
    BUFFER_SIZE = 5
    
    # Recognition thresholds
    MAX_DISTANCE = 25.0
    CONFIDENCE_THRESHOLD = 0.45
    MIN_CONFIDENCE_COUNT = 3

    # Counter for consecutive successful recognitions
    successful_frames = 0
    REQUIRED_SUCCESSFUL_FRAMES = 10

    # No face detection timer
    no_face_start_time = None
    NO_FACE_DELAY = 2  # 5 seconds delay

    while True:
        ret, frame = cap.read()
        if not ret:
            continue

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_detector.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=4,
            minSize=(30, 30),
            maxSize=(300, 300)
        )

        if len(faces) == 1:  # Face detected
            no_face_start_time = None  # Reset timer
            x, y, w, h = faces[0]
            try:
                face = frame[y:y+h, x:x+w]
                face_gray = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
                face_resized = cv2.resize(face_gray, (50, 50))
                face_array = face_resized.flatten().astype(np.float32) / 255.0
                face_array = face_array.reshape(1, -1)
                
                distances, indices = global_model.kneighbors(face_array)
                closest_distance = distances[0][0]
                identified_person = global_model.predict(face_array)[0]
                
                confidence = 1 - (closest_distance / MAX_DISTANCE)
                
                last_predictions.append((identified_person, confidence))
                if len(last_predictions) > BUFFER_SIZE:
                    last_predictions.pop(0)
                
                stable_recognition = False
                if len(last_predictions) == BUFFER_SIZE:
                    confident_predictions = sum(1 for p, c in last_predictions 
                                             if p == identified_person and c > CONFIDENCE_THRESHOLD)
                    stable_recognition = confident_predictions >= MIN_CONFIDENCE_COUNT
                
                if confidence > CONFIDENCE_THRESHOLD and stable_recognition:
                    successful_frames += 1
                    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    
                    # Only display and count if we have a valid identification
                    if identified_person is not None:
                        display_name = identified_person.split('_')[0]
                        cv2.putText(frame, display_name, 
                                  (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
                        
                        # If we have enough successful frames, mark attendance and exit
                        if successful_frames >= REQUIRED_SUCCESSFUL_FRAMES:
                            add_attendance(identified_person)
                            cv2.putText(frame, 'Attendance Marked!', (30, 30), 
                                      cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                            cv2.imshow('Attendance Check', frame)
                            cv2.waitKey(1000)
                            break
                    else:
                        successful_frames = 0  # Reset if no valid identification
                
            except Exception as e:
                print(f"Error processing face: {str(e)}")
                continue
        else:
            successful_frames = 0
            current_time = time.time()
            
            if len(faces) > 1:
                no_face_start_time = None  # Reset timer for multiple faces
                cv2.putText(frame, 'Please show only one face', (30, 30), 
                          cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
            else:  # No face detected
                if no_face_start_time is None:
                    no_face_start_time = current_time
                elif current_time - no_face_start_time >= NO_FACE_DELAY:
                    cv2.putText(frame, 'No face detected', (30, 30), 
                              cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

        cv2.imshow('Attendance Check', frame)
        bring_window_to_front('Attendance Check')

        if cv2.waitKey(1) == 27:
            break

    cap.release()
    cv2.destroyAllWindows()
    return redirect(url_for('index'))

# Add this new route after the start() route
@app.route('/clear', methods=['GET'])
def clear():
    # Clear the attendance CSV file but keep the header
    with open(attendance_csv, 'w') as f:
        f.write('Name,Roll,Time')
    return redirect(url_for('index'))

# Add this new route before your existing /add route
@app.route('/add_user')
def add_user():
    return render_template('add_user.html')

# Your existing add route remains the same
@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        newusername = request.form['newusername']
        newuserid = request.form['newuserid']
        
        # Reset the global model
        global global_model
        global_model = None
        
        userimagefolder = os.path.join(faces_dir, newusername + '_' + str(newuserid))
        if not os.path.isdir(userimagefolder):
            os.makedirs(userimagefolder)
        else:
            # Clear existing images if the folder exists
            for file in os.listdir(userimagefolder):
                os.remove(os.path.join(userimagefolder, file))
                
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        cap.set(cv2.CAP_PROP_FPS, 60)
        
        i, j = 0, 0
        no_face_start_time = None
        NO_FACE_DELAY = 5  # 5 seconds delay
        
        while i < 100:
            ret, frame = cap.read()
            if ret:
                faces = extract_faces(frame)
                current_time = time.time()
                
                if len(faces) > 0:
                    no_face_start_time = None  # Reset timer
                    for (x, y, w, h) in faces:
                        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 20), 2)
                        cv2.putText(frame, f'Scanning: {i}/100', (30, 30), 
                                  cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 20), 2)
                        
                        if j % 2 == 0:
                            name = newusername + '_' + str(i) + '.jpg'
                            face_img = frame[y:y + h, x:x + w]
                            cv2.imwrite(os.path.join(userimagefolder, name), face_img)
                            i += 1
                            if i >= 100:
                                break
                        j += 1
                else:
                    if no_face_start_time is None:
                        no_face_start_time = current_time
                    elif current_time - no_face_start_time >= NO_FACE_DELAY:
                        cv2.putText(frame, 'No face detected!', (30, 30), 
                                  cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

                cv2.imshow('Adding new Student', frame)
                bring_window_to_front('Adding new Student')

                if cv2.waitKey(1) == 27:
                    break

        cap.release()
        cv2.destroyAllWindows()
        
        print('Training Model')
        train_model()
        names, rolls, times, l = extract_attendance()
        
        return redirect(url_for('index'))
    
    return redirect(url_for('index'))

@app.route('/list_users')
def list_users():
    user_dirs = os.listdir(faces_dir)
    return render_template('list_users.html', user_dirs=user_dirs)

@app.route('/clear_database')
def clear_database():
    try:
        # Remove all contents of faces directory
        shutil.rmtree(faces_dir)
        # Recreate the empty faces directory
        os.makedirs(faces_dir)
        
        # Remove the .pkl model file if it exists
        model_path = os.path.join(static_dir, 'face_recognition_model.pkl')
        if os.path.exists(model_path):
            os.remove(model_path)
            
        return redirect(url_for('index'))
    except Exception as e:
        print(f"Error clearing database: {str(e)}")
        return redirect(url_for('list_users'))

# Main function which runs the Flask App
if __name__ == '__main__':
    app.run(debug=True, port=1000)
