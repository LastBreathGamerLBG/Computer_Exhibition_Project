import time
import sys
import cv2
import pygetwindow as gw
import os
from flask import Flask, request, render_template, redirect, session, url_for
from datetime import date
from datetime import datetime
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd
import joblib

# Defining Flask App
app = Flask(__name__)

# Determine the base directory depending on whether the app is running as a script or bundled executable
if getattr(sys, 'frozen', False):
    # Running as a bundled executable
    base_dir = sys._MEIPASS
else:
    # Running as a normal script
    base_dir = os.getcwd()

# Paths for resources like Haar Cascade
haarcascade_path = os.path.join(base_dir, "haarcascade_frontalface_default.xml")

# Load the Haar Cascade
face_cascade = cv2.CascadeClassifier(haarcascade_path)

def bring_window_to_front(window_name):
    open_windows = gw.getAllTitles()
        
    if window_name in open_windows:
        window = gw.getWindowsWithTitle(window_name)[0]
        
        if window.isActive:
            return
        # Try minimizing and then restoring the window
        window.minimize()
        time.sleep(0.1) 
        window.restore() 
            
        # Activate the window to bring it to the front
        window.activate()
        window.alwaysOnTop = True 

# Saving Date today in 2 different formats
datetoday = date.today().strftime("%m_%d_%y")
datetoday2 = date.today().strftime("%d-%B-%Y")

# Initializing VideoCapture object to access WebCam
face_detector = cv2.CascadeClassifier(haarcascade_path)
try:
    cap = cv2.VideoCapture(1)
except:
    cap = cv2.VideoCapture(0)

# Define paths for directories
attendance_dir = os.path.join(base_dir, 'Attendance')
static_dir = os.path.join(base_dir, 'static')
faces_dir = os.path.join(static_dir, 'faces')

# If these directories don't exist, create them
if not os.path.isdir(attendance_dir):
    os.makedirs(attendance_dir)

if not os.path.isdir(static_dir):
    os.makedirs(static_dir)

if not os.path.isdir(faces_dir):
    os.makedirs(faces_dir)

# Create attendance CSV file if it doesn't exist
attendance_csv = os.path.join(attendance_dir, f'Attendance-{datetoday}.csv')
if not os.path.exists(attendance_csv):
    with open(attendance_csv, 'w') as f:
        f.write('Name,Roll,Time')

# Get a number of total registered users
def totalreg():
    return len(os.listdir(faces_dir))

# Extract the face from an image
def extract_faces(img):
    if img != []:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        face_points = face_detector.detectMultiScale(gray, 1.3, 5)
        return face_points
    else:
        return []

# Identify face using ML model
def identify_face(facearray):
    model_path = os.path.join(static_dir, 'face_recognition_model.pkl')
    model = joblib.load(model_path)
    return model.predict(facearray)

# A function which trains the model on all the faces available in faces folder
def train_model():
    faces = []
    labels = []
    userlist = os.listdir(faces_dir)
    for user in userlist:
        for imgname in os.listdir(os.path.join(faces_dir, user)):
            img = cv2.imread(os.path.join(faces_dir, user, imgname))
            resized_face = cv2.resize(img, (50, 50))
            faces.append(resized_face.ravel())
            labels.append(user)
    faces = np.array(faces)
    knn = KNeighborsClassifier(n_neighbors=5)
    knn.fit(faces, labels)
    joblib.dump(knn, os.path.join(static_dir, 'face_recognition_model.pkl'))

# Extract info from today's attendance file in attendance folder
def extract_attendance():
    df = pd.read_csv(attendance_csv)
    names = df['Name']
    rolls = df['Roll']
    times = df['Time']
    l = len(df)
    return names, rolls, times, l

# Add Attendance of a specific user
def add_attendance(name):
    username = name.split('_')[0]
    userid = name.split('_')[1]
    current_time = datetime.now().strftime("%H:%M:%S")
    
    df = pd.read_csv(attendance_csv)
    if str(userid) not in list(df['Roll']):
        with open(attendance_csv, 'a') as f:
            f.write(f'\n{username},{userid},{current_time}')

# Our main page
@app.route('/')
def index():
    names, rolls, times, l = extract_attendance()    
    return render_template('index.html', names=names, rolls=rolls, times=times, l=l, totalreg=totalreg(), datetoday2=datetoday2) 

# This function will run when we click on Take Attendance Button
@app.route('/start', methods=['GET'])
def start():
    model_path = os.path.join(static_dir, 'face_recognition_model.pkl')
    if not os.path.exists(model_path):
        return render_template('index.html', totalreg=totalreg(), datetoday2=datetoday2, mess='There is no trained model in the static folder. Please add a new face to continue.')

    cap = cv2.VideoCapture(0)
    ret = True
    recognized_faces = set()  # Set to track recognized faces during the session

    while True:
        # Read a frame from the camera
        ret, frame = cap.read()

        # Convert the frame to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Detect faces in the grayscale frame
        faces = face_detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)

        # Draw rectangles around the detected faces
        for (x, y, w, h) in faces:
            face = cv2.resize(frame[y:y + h, x:x + w], (50, 50))

            # Identify the face using the model
            identified_person = identify_face(face.reshape(1, -1))[0]

            # Check if the identified person is registered or unknown
            if identified_person in os.listdir(faces_dir):
                # Draw a green rectangle for recognized person
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                if identified_person not in recognized_faces:
                    add_attendance(identified_person)
                    recognized_faces.add(identified_person)
                # Show the recognized person's name
                cv2.putText(frame, f'{identified_person}', 
                            (x + 6, y - 6), 
                            cv2.FONT_HERSHEY_SIMPLEX, 
                            1, (0, 255, 0), 2)  # Green text
            else:
                # Draw a red rectangle for unknown person
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)

            # Show the identified name or "Unknown" near the detected face
            cv2.putText(frame, f'{identified_person if identified_person in os.listdir(faces_dir) else "Unknown"}', 
                        (x + 6, y - 6), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 20), 2)

        # Display the resulting frame
        cv2.imshow('Attendance Check', frame)
        bring_window_to_front('Attendance Check')

        # Wait for the user to press 'Esc' to quit or continue
        key = cv2.waitKey(1) & 0xFF
        if key == 27:  # ESC key pressed
            break  # Exit the loop and close the camera window

    # Release the camera and close OpenCV window
    cap.release()
    cv2.destroyAllWindows()

    # After capturing, redirect to the main page ("/")
    return redirect(url_for('index'))

# This function will run when we add a new user
@app.route('/add', methods=['GET', 'POST'])
def add():
    newusername = request.form['newusername']
    newuserid = request.form['newuserid']
    userimagefolder = os.path.join(faces_dir, newusername + '_' + str(newuserid))
    if not os.path.isdir(userimagefolder):
        os.makedirs(userimagefolder)
    cap = cv2.VideoCapture(0)
    i, j = 0, 0
    while 1:
        _, frame = cap.read()
        faces = extract_faces(frame)
        for (x, y, w, h) in faces:
            cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 0, 20), 2)
            cv2.putText(frame, f'Scanning: {i}/50', (30, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 20), 2, cv2.LINE_AA)
            if j % 10 == 0:
                name = newusername + '_' + str(i) + '.jpg'
                cv2.imwrite(os.path.join(userimagefolder, name), frame[y:y + h, x:x + w])
                i += 1
            j += 1
        if j == 500:
            break
        cv2.imshow('Adding new Student', frame)
        bring_window_to_front('Adding new Student')

        if cv2.waitKey(1) == 27:
            break
    cap.release()
    cv2.destroyAllWindows()
    print('Training Model')
    train_model()
    names, rolls, times, l = extract_attendance()   
    if totalreg() > 0:
        return redirect(url_for('index'))
    else:
        return render_template('index.html', names=names, rolls=rolls, times=times, l=l, totalreg=totalreg(), datetoday2=datetoday2)

# Main function which runs the Flask App
if __name__ == '__main__':
    app.run(debug=True, port=1000)
